var onov = (window.location.href.indexOf("http://ocean") == 0 || window.location.href.indexOf("https://ocean") == 0);
var weLocal = window.location.protocol === "file:" || window.location.hostname == "localhost";

var keyline

var screwfix = {
	colours: {
		blue:  '#0053A0',
		red:   '#EC1D25'
	}
}

var ad = {
	width: 300,
	height: 600
}

function startBanner() {
	loadSvgs();
}

function loadSvgs() {
	fbf.loadSvgs(setupAd);
}

/*$$$$$\  $$$$$$$$\ $$$$$$$$\ $$\   $$\ $$$$$$$\
$$  __$$\ $$  _____|\__$$  __|$$ |  $$ |$$  __$$\
$$ /  \__|$$ |         $$ |   $$ |  $$ |$$ |  $$ |
\$$$$$$\  $$$$$\       $$ |   $$ |  $$ |$$$$$$$  |
 \____$$\ $$  __|      $$ |   $$ |  $$ |$$  ____/
$$\   $$ |$$ |         $$ |   $$ |  $$ |$$ |
\$$$$$$  |$$$$$$$$\    $$ |   \$$$$$$  |$$ |
 \______/ \________|   \__|    \______/ \_*/

function setupAd() {
	fbf.clean(_root);
	fbf.replaceSVGDefs();
	fbf.displayBlock(_root);
	_root.buttonMode = true;
	_root.style.cssText += "overflow:hidden;";
	// banner background colour
	_root.style.backgroundColor = '#FFFFFF';
	// add keyline
	keyline = addKeylineTo(_root, ad.width, ad.height, screwfix.colours.blue, 1);
	// add listeners
	addListeners();
	// hide sections
	hideSections();
	shieldY = mc_shield._y
	// start ad
	startFlow();

}

function addListeners() {
	_root.addEventListener("click", handleClick);
	_root.addEventListener("mouseenter", rollover);
	_root.addEventListener("mouseout", rollout);
}

function hideSections() {
	fbf.hide(banner_button);
}

/*$$$$$$\ $$\       $$$$$$\  $$\      $$\ 
$$  _____|$$ |     $$  __$$\ $$ | $\  $$ |
$$ |      $$ |     $$ /  $$ |$$ |$$$\ $$ |
$$$$$\    $$ |     $$ |  $$ |$$ $$ $$\$$ |
$$  __|   $$ |     $$ |  $$ |$$$$  _$$$$ |
$$ |      $$ |     $$ |  $$ |$$$  / \$$$ |
$$ |      $$$$$$$$\ $$$$$$  |$$  /   \$$ |
\__|      \________|\______/ \__/     \_*/

function startFlow() {
	animate();
}

var masterTl;
var buttonBackground, buttonText;
var animationDefaults = {transformOrigin: '50% 50%', ease: 'back.out(1.7)', duration: 0.5};
var allowButtonRollover = false;

function animate() {
	buttonBackground = banner_button.getElementsByTagName('path')[0]
	buttonText = banner_button.getElementsByTagName('path')[1]

	// master timeline
	masterTl = gsap.timeline({onComplete: function() { allowButtonRollover = true }});
	masterTl.add( intro() );
	masterTl.add( middle(), '> 0.75');
	masterTl.add( end(), '< 3.5' );
}

function intro() {
	gsap.set(screwfix_logo, {y:"+=40"});
	var tl = gsap.timeline({defaults: animationDefaults});
	tl.fromTo(banner_curtain, {alpha: 1}, {alpha: 0, duration: 1});
	tl.add( hideSections );
	tl.add( function() { fbf.show(banner_text) });
///////// Screwfix Deals Lockup animation /////////////////////////////////////////////////////////////
	tl.from(screwfix_logo, {scale: 0, transformOrigin: '50% 50%', ease: 'back.out(1.7)', duration: 0.25}, '<');
	tl.from(deals, {y:"+=320", ease: 'back.out(1)', duration: 0.25},'> 0.25');
	tl.to(screwfix_logo, {y:"-=40", ease: 'back.out(1.7)', duration: 0.25}, '< 0.1');
///////// Zooms in and creates the Red Background /////////////////////////////////////////////////////
	tl.to(banner_text, {y:"-=60", x:"-=110", transformOrigin: '50% 50%', scale: 21, ease: 'power1.out', duration: 0.25}, '< 0.9');
    tl.to(banner_text, {alpha: 0, duration: 0.25}, '< 0.25');
///////// White Messaging Animates in ////////////////////////////////////////////////////////////////
    tl.from(sf_logo, {alpha: 0, y: "+=50", duration: 0.25}, '< 0.25');
    tl.from(word_01, {alpha: 0, y: "+=50", duration: 0.25}, '< 0.25');
    tl.from(word_02, {alpha: 0, y: "+=50", duration: 0.25}, '< 0.25');
    tl.from(word_03, {alpha: 0, y: "+=50", duration: 0.25}, '< 0.25');
    tl.from(word_04, {alpha: 0, y: "+=50", duration: 0.25}, '< 0.25');
    tl.from(word_05, {alpha: 0, y: "+=50", duration: 0.25}, '< 0.25');
 ///////// Tools come in //////////////////////////////////////////////////////////////////////////////   
    tl.from(tool_01, {y: "+=70", x: "-=80", ease: 'back.out(1)', duration: 0.25}, '< 0.25');
    tl.from(tool_02, {y: "+=230", x: "-=0", ease: 'back.out(1)', duration: 0.25}, '<');
    tl.from(tool_03, {y: "+=230", x: "-=0", ease: 'back.out(1)', duration: 0.25}, '<');
    tl.from(tool_04, {y: "+=70", x: "+=80", ease: 'back.out(1)', duration: 0.25}, '<');
    tl.from(word_07, {alpha: 0, y: "+=50", duration: 0.25}, '< 0.3');
    tl.from(word_08, {alpha: 0, y: "+=50", duration: 0.25}, '< 0.25');
///////// Tools rotate into the DONE letters //////////////////////////////////////////////////////////
    tl.to(tool_01, {scaleX: 0, ease: 'power1.out', duration: 0.1}, '< 0.25');
    tl.to(tool_02, {scaleX: 0, ease: 'power1.out', duration: 0.1}, '<');
    tl.to(tool_03, {scaleX: 0, ease: 'power1.out', duration: 0.1}, '<');
    tl.to(tool_04, {scaleX: 0, ease: 'power1.out', duration: 0.1}, '<');
    tl.from(letter_D, {scaleX: 0, ease: 'power1.out', duration: 0.1}, '< 0.1');
    tl.from(letter_O, {scaleX: 0, ease: 'power1.out', duration: 0.1}, '<');
    tl.from(letter_N, {scaleX: 0, ease: 'power1.out', duration: 0.1}, '<');
    tl.from(letter_E, {scaleX: 0, ease: 'power1.out', duration: 0.1}, '<');
    rotateTools();
	return tl;
}

function middle() {
	gsap.set(mc_shield, {y:"-=450"});
	var tl = gsap.timeline({defaults: animationDefaults});
	tl.add( function() { fbf.hide() });
///////// Messaging pulses and move up out of view ////////////////////////////////////////////////////
    tl.to(banner_tools_text, {transformOrigin: '50% 50%', scale:1.05, duration: 0.25}, '< 0.25');
    tl.to(banner_tools_text, {transformOrigin: '50% 50%', scale:1, duration: 0.25}, '< 0.25');
    tl.to(banner_tools_text, {alpha:0, y: "-=550", ease: "back.inOut(1.7)", duration: 0.25}, '< 0.5');
///////// Red turns into the Deckchar /////////////////////////////////////////////////////////////////
    tl.to(banner_background_red, {alpha:0, ease: "power1.out", duration: 0.25}, '< 0.5');
    tl.from(banner_toolkit, {transformOrigin: '30% 30%', scale:10, ease: "power4.out", duration: 0.75}, '<');
///////// Shield Dropping Animation ///////////////////////////////////////////////////////////////////
    tl.to(mc_shield, {y: "+=450", ease: "bounce.out", duration: 1.75}, '< 0.25');
    moveBackground();
	return tl;
}

function end() {
	var tl = gsap.timeline({defaults: animationDefaults});
	tl.add( function() { fbf.show(banner_button) });
///////// Yellow Solid comes in and moves Deckchair up ////////////////////////////////////////////////
    tl.from(banner_endframe, {y: "+=450", duration: 0.5}, '< 0.5');
    tl.to(banner_toolkit, {y: "-=205", duration: 0.5}, '<');
///////// SUMMER OFFERS Endframe Messaging and CTA ////////////////////////////////////////////////////
    tl.from(endMessaging_1, {x: "-=290", ease: 'back.out(1.2)', duration: 0.5}, '< 0.5');
    tl.from(endMessaging_2, {x: "+=290", ease: 'back.out(1.2)', duration: 0.5}, '<');
	tl.from(banner_button, {y: "+=100", ease: 'back.out(1.2)', duration: 0.5}, '< 0.5');
	tl.to(endMessaging, {transformOrigin: '50% 50%', scale:1.05, duration: 0.25}, '< 1');
    tl.to(endMessaging, {transformOrigin: '50% 50%', scale:1, duration: 0.25}, '< 0.25');
    tl.to(banner_button, {ease: "back.out(1.7)", transformOrigin: '50% 50%', scale:1.1, duration: 0.25}, '< 0.25');
	tl.to(banner_button, {ease: "back.out(1.7)", transformOrigin: '50% 50%', scale:1, duration: 0.25}, '< 0.25');

	return tl;
}

function rotateTools() {
	var tl = gsap.timeline({defaults: animationDefaults});
	//tl.to(tool_01, {rotate: -60, ease: "power1.out", duration: 5}, '< 1');
}

function moveBackground() {
	var tl = gsap.timeline({defaults: animationDefaults});
	tl.to(banner_background, {x:-100, ease: "power1.out", duration: 15}, '< 5');
}

var shieldY

function moveShield() {
	gsap.killTweensOf(mc_shield);
	gsap.to(mc_shield, {y: shieldY-100, duration: 0.5/*,onComplete:returnShield*/});
}

function returnShield() {
	gsap.killTweensOf(mc_shield);
	gsap.to(mc_shield, {y: shieldY, ease: "bounce.out", duration: 1});
}

function rollover(e) {
	if(allowButtonRollover && masterTl.progress() >= 1) {	
	var tl = gsap.timeline({defaults: animationDefaults});	
		tl.to(banner_button, {ease: "back.out(1.7)", transformOrigin: '50% 50%', scale:1.1, duration: 0.25}, '<');
		tl.to(banner_button, {ease: "back.out(1.7)", transformOrigin: '50% 50%', scale:1, duration: 0.25}, '< 0.25');
		moveShield();
	}
}

function rollout(e) {
	if(allowButtonRollover) {
		
		returnShield();
	}	
}

/*$$$$$\   $$$$$$\  $$\      $$\ 
$$  __$$\ $$  __$$\ $$$\    $$$ |
$$ |  $$ |$$ /  $$ |$$$$\  $$$$ |
$$ |  $$ |$$ |  $$ |$$\$$\$$ $$ |
$$ |  $$ |$$ |  $$ |$$ \$$$  $$ |
$$ |  $$ |$$ |  $$ |$$ |\$  /$$ |
$$$$$$$  | $$$$$$  |$$ | \_/ $$ |
\_______/  \______/ \__|     \_*/

var _root = $('root');